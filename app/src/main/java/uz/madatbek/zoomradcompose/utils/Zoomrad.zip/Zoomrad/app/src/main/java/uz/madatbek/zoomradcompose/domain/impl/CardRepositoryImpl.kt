package uz.madatbek.zoomradcompose.domain.impl

import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.data.sourse.remote.api.CardApi
import uz.madatbek.zoomradcompose.data.sourse.remote.api.Register
import uz.madatbek.zoomradcompose.data.sourse.remote.api.TransferApi
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.AddCardData
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.CardData
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.StringData
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.GetCardOwnerByPanData
import uz.madatbek.zoomradcompose.domain.CardRepository
import uz.madatbek.zoomradcompose.utils.emitWith
import uz.madatbek.zoomradcompose.utils.safetyFlow
import uz.madatbek.zoomradcompose.utils.toResultData
import javax.inject.Inject

class CardRepositoryImpl @Inject constructor(
    val cardApi: CardApi,
    val register: Register,
    private val transferApi: TransferApi
):CardRepository {
    override fun addCard(card: AddCardData): Flow<Result<StringData>> = safetyFlow{
        cardApi.addCard(MyShar.getAccessToken(), card)
            .toResultData()
            .map { StringData(it.message) }
            .emitWith()
    }
    override fun getCardOwnerByPan(card: GetCardOwnerByPanData): Flow<Result<GetCardOwnerByPanData>> = safetyFlow{
        transferApi.getCardOwnerByPan(authorization =MyShar.getAccessToken() , card = card)
         .toResultData()
         .emitWith()
    }
    override fun getAllCards() = flow{
        cardApi.getAllCards(authorization =MyShar.getAccessToken())
            .toResultData()
            .emitWith()
    }
    override fun deleteCard(): Flow<Result<StringData>> = safetyFlow{
        cardApi.deleteCard(authorization = MyShar.getAccessToken())
            .toResultData()
            .emitWith()
    }
}