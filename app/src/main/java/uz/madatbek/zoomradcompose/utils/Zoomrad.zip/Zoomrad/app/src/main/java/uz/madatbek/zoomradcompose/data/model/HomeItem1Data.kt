package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class HomeItem1Data(
    @DrawableRes val icon:Int,
    val cost:Int,
    val  currency:Int,
    val name:Int
)
