import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.InvocationKind
import kotlin.contracts.contract

class ResultData<T> {

    var value:T?=null
    @SinceKotlin("1.3")
    inline fun <T> Result<T>.onFailure(action: (exception: Throwable) -> Unit): Result<T> {

        exceptionOrNull()?.let { action(it) }
        return this
    }

    @SinceKotlin("1.3")
    inline fun <reified T> Result<T>.onSuccess(action: (value: T) -> Unit): Result<T> {

        if (isSuccess) {
            action(value as T)
        }
        return this
    }
}