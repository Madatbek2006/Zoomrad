package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class HomeItem3Data(
    @DrawableRes val icon:Int,
    var valuta: String,
    var pokypka: String,
    var prodaja: String
)