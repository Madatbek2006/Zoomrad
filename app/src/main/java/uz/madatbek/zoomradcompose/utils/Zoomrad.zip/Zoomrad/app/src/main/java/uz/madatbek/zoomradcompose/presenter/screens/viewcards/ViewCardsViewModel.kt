package uz.madatbek.zoomradcompose.presenter.screens.viewcards

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cafe.adriel.voyager.core.model.ScreenModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import org.orbitmvi.orbit.syntax.simple.intent
import org.orbitmvi.orbit.syntax.simple.postSideEffect
import org.orbitmvi.orbit.viewmodel.container
import uz.madatbek.zoomradcompose.domain.CardRepository
import uz.madatbek.zoomradcompose.utils.postUiState
import javax.inject.Inject

@HiltViewModel
class ViewCardsViewModel @Inject constructor(
    private val cardRepository: CardRepository
) : ViewModel(), ScreenModel, ViewCardsContract.Model {
    override val container = container<ViewCardsContract.UIState, ViewCardsContract.SideEffect>(
        ViewCardsContract.UIState.LoadAllCards(data = emptyList())
    )

   init{
        cardRepository.getAllCards().onEach {
            it.onSuccess {
                intent { postUiState(ViewCardsContract.UIState.LoadAllCards(it)) }
            }
            it.onFailure {
                intent { postSideEffect(ViewCardsContract.SideEffect.Toast(it.message ?: "Unknown Error!!")) }
            }
        }.launchIn(viewModelScope)

    }

    override fun onEventDispatcher(intent: ViewCardsContract.Intent) {

    }
}



