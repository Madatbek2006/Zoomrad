package uz.madatbek.zoomradcompose.data.sourse.remote.singup

data class SMSTokenData(
    val token:String
)