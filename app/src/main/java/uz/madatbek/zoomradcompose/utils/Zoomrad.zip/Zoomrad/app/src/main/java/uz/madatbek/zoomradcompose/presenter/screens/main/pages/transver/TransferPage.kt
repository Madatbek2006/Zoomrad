package uz.madatbek.zoomradcompose.presenter.screens.main.pages.transver

import CardNumberVisualTransformation
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.hilt.getViewModel
import cafe.adriel.voyager.navigator.tab.Tab
import cafe.adriel.voyager.navigator.tab.TabOptions
import org.orbitmvi.orbit.compose.collectAsState
import uz.madatbek.zoomradcompose.R
import uz.madatbek.zoomradcompose.data.model.TransferItem1Data
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.GetCardOwnerByPanData
import uz.madatbek.zoomradcompose.ui.theme.ZoomradTheme
import uz.madatbek.zoomradcompose.utils.myLog

object TransferPage : Tab {
    override val options: TabOptions
        @Composable
        get() {
            val title = stringResource(id = R.string.transfer)
            val icon =
                rememberVectorPainter(image = ImageVector.vectorResource(id = R.drawable.ic_transfer))

            return remember {
                TabOptions(
                    index = 0u,
                    title = title,
                    icon = icon
                )
            }
        }

    @Composable
    override fun Content() {
        val viewModel = getViewModel<TransferViewModel>()
        ZoomradTheme {
            TransferComponent(viewModel.collectAsState().value,viewModel::onEventDispatchers)
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferComponent(uiState:TransferContract.UIState,onEventDispatchers: (TransferContract.Intent) -> Unit) {
    val textState = remember { mutableStateOf("") }
    val costText = remember { mutableStateOf("") }
    if (textState.value.length==16){
        "onEventDispatchers".myLog()
        onEventDispatchers(TransferContract.Intent.GetCardByPan(
            GetCardOwnerByPanData(textState.value)
        ))
    }

    val isSuccess= remember {
        mutableStateOf(false)
    }

    val cardName= remember {
        mutableStateOf("")
    }

    when(uiState){
        is TransferContract.UIState.Text->{
            cardName.value=uiState.txt
            isSuccess.value=uiState.isSuccess
        }
    }
    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(color = colorResource(id = R.color.app_bg))
        ) {


            Spacer(modifier = Modifier.fillMaxHeight(0.1f))
            TransferEditText(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(horizontal = 16.dp)
                    .clip(
                        RoundedCornerShape(8.dp)
                    ),
                text = textState
            )
            if (textState.value.length==16){
                Text(
                    modifier = Modifier.padding(start = 16.dp,top=8.dp),
                    text = if (cardName.value.isEmpty()) stringResource(id = R.string.transfer_page_wait) else cardName.value,
                    fontSize = 10.sp,
                    color = if (isSuccess.value)colorResource(id = R.color.zumrat) else colorResource(id = R.color.zumrat_exception)
                )
            }


            Text(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 32.dp),
                text = stringResource(id = R.string.transfer_page_transfer_amount),
                fontSize = 12.sp
            )
            TextField(
                value =costText.value ,
                onValueChange = {
                    costText.value=it
                },
                placeholder = {
                    Text(
                        modifier = Modifier.fillMaxWidth(),
                        text = stringResource(id = R.string.transfer_page_sum),
                        fontSize = 24.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                        )
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                textStyle = TextStyle(
                    fontSize = 24.sp,
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 16.dp),
                colors = TextFieldDefaults.textFieldColors(
                    containerColor = Color.Transparent, // Устанавливаем прозрачный цвет контейнера
                    unfocusedIndicatorColor = Color.Transparent, // Цвет индикатора, когда поле не в фокусе
                    focusedIndicatorColor = Color.Transparent  // Цвет индикатора, когда поле в фокусе
                ),
            )


            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp)
            ) {
                TransferItem(
                    modifier = Modifier.weight(1f),
                    data = TransferItem1Data(R.drawable.ic_credit, R.string.transfer_page_item_1),
                    onCLick = {

                    }
                )
                TransferItem(
                    modifier = Modifier.weight(1f),
                    data = TransferItem1Data(R.drawable.ic_credit, R.string.transfer_page_item_2),
                    onCLick = {

                    }
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp)
                    .padding(top = 56.dp)
                    .height(100.dp)
                    .clip(
                        RoundedCornerShape(16.dp)
                    )
                    .background(colorResource(id = R.color.zumrat))
            ) {
                Column(modifier = Modifier.align(Alignment.Center)) {
                    Image(
                        modifier = Modifier
                            .height(24.dp)
                            .width(24.dp)
                            .clip(RoundedCornerShape(300.dp))
                            .background(Color.White)
                            .padding(6.dp)
                            .align(Alignment.CenterHorizontally)
                            .clickable(
                                onClick = {
                                    onEventDispatchers(TransferContract.Intent.OpenAddScreen)
                                },
                                indication = rememberRipple(
                                    bounded = false,
                                    radius = 20.dp,
                                ),
                                interactionSource = remember {
                                    MutableInteractionSource()
                                }
                            ),
                        painter = painterResource(id = R.drawable.plus),
                        contentDescription = null,
                        colorFilter = ColorFilter.tint(colorResource(id = R.color.zumrat))
                    )
                    Text(
                        text = stringResource(id = R.string.transfer_page_add_card),
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 8.dp),
                        color = Color.White
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(color = if (isSuccess.value) colorResource(id = R.color.zumrat) else Color.Gray)
                            .clickable {
                                if (isSuccess.value&&costText.value.isNotEmpty()){
                                    onEventDispatchers(TransferContract.Intent.Transfer(pan = textState.value, amount = costText.value.toLong()))
                                }
                            }
                    ) {
                        Text(
                            modifier = Modifier
                                .padding(16.dp)
                                .align(Alignment.Center),
                            text = "Продолжить",
                            color = Color.White
                        )
                    }
                    Text(
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 16.dp),
                        text = "Нажимая\"Продолжить\", Вы соглашаетесь с",
                        fontSize = 10.sp
                    )
                    Text(
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                        text = "Условиями оферты",
                        fontSize = 10.sp,
                        color = colorResource(id = R.color.zumrat)
                    )

                    Box(modifier = Modifier.height(64.dp))
                }
            }
        }
    }
}

@Composable
fun TransferItem(
    modifier: Modifier,
    data: TransferItem1Data,
    onCLick: ((TransferItem1Data) -> Unit)
) {
    Box(
        modifier = modifier
            .height(80.dp)
            .clip(RoundedCornerShape(16.dp))


            .clickable {},
//                onClick = {
//                    onClick(data)
//                }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            Image(
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(start = 12.dp)
                    .padding(vertical = 12.dp)
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .padding(12.dp),
                painter = painterResource(id = data.icon), contentDescription = null,
                colorFilter = ColorFilter.tint(
                    color = colorResource(
                        id = R.color.zumrat
                    )
                )
            )
            Row(
                modifier = Modifier
                    .fillMaxHeight()
                    .padding(start = 8.dp),
            ) {
                Text(

                    modifier = Modifier.align(Alignment.CenterVertically),
                    text = stringResource(id =data.name),
                    fontSize = 10.sp
                )
            }
        }

    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransferEditText(modifier: Modifier, text: MutableState<String>) {
    Box(
        modifier = modifier
    ) {
        TextField(
            value = text.value,
            onValueChange = { newText ->
                if (newText.length>=17)return@TextField
                text.value = newText
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            placeholder = {
//                if (textState.value.isEmpty()){
                Text(text = "Номер карты получателя", fontSize = 16.sp, color = Color.Gray)
//                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .align(Alignment.CenterStart)
                .padding(start = 16.dp, end = 56.dp),
            colors = TextFieldDefaults.textFieldColors(
                containerColor = Color.Transparent, // Устанавливаем прозрачный цвет контейнера
                unfocusedIndicatorColor = Color.Transparent, // Цвет индикатора, когда поле не в фокусе
                focusedIndicatorColor = Color.Transparent  // Цвет индикатора, когда поле в фокусе
            ),
            visualTransformation = CardNumberVisualTransformation()
        )
        Image(
            modifier = Modifier
                .padding(16.dp)
                .align(Alignment.CenterEnd),
            painter = painterResource(id = R.drawable.ic_scan),
            contentDescription = null,
            colorFilter = ColorFilter.tint(colorResource(id = R.color.zumrat))
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CostEditTExt(modifier: Modifier, text: MutableState<String>) {
    TextField(
        value = text.value,
        onValueChange = { newText ->
            text.value = newText

        },
        label = {
//                if (textState.value.isEmpty()){
            Text(text = "0 сум", fontSize = 24.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
//                }
        },
        modifier = modifier,
        colors = TextFieldDefaults.textFieldColors(
            containerColor = Color.Transparent, // Устанавливаем прозрачный цвет контейнера
            unfocusedIndicatorColor = Color.Transparent, // Цвет индикатора, когда поле не в фокусе
            focusedIndicatorColor = Color.Transparent  // Цвет индикатора, когда поле в фокусе
        )
    )
}


@Preview
@Composable
fun TransferPreview() {
    TransferComponent(
        uiState = TransferContract.UIState.InitUIState
    ) {

    }
}