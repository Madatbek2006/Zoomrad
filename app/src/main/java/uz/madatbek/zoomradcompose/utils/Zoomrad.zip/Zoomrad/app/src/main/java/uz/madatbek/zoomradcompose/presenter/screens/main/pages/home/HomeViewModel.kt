package uz.madatbek.zoomradcompose.presenter.screens.main.pages.home

import androidx.lifecycle.ViewModel
import cafe.adriel.voyager.core.model.ScreenModel
import dagger.hilt.android.lifecycle.HiltViewModel
import org.orbitmvi.orbit.Container
import org.orbitmvi.orbit.syntax.simple.intent
import org.orbitmvi.orbit.viewmodel.container
import uz.madatbek.zoomradcompose.presenter.screens.addcard.AddCardScreen
import uz.madatbek.zoomradcompose.presenter.screens.viewcards.ViewCardsScreen
import uz.madatbek.zoomradcompose.utils.navigation.AppNavigator
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val navigator: AppNavigator
):ViewModel(),ScreenModel,HomeContract.Model {
    override val container =container<HomeContract.UIState, HomeContract.SideEffect>(HomeContract.UIState.InitUIState)



    override fun onEventDispatchers(intent: HomeContract.Intent) =intent{
        when(intent){
            HomeContract.Intent.OpenAddScreen->{
                navigator.navigateTo(AddCardScreen())
            }
            HomeContract.Intent.OpenViewCardsScreen->{
                navigator.navigateTo(ViewCardsScreen())
            }
        }
    }
}