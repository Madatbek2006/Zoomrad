package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class MoreItem1Data(
   @DrawableRes val icon:Int,
    val name:Int
)