import android.annotation.SuppressLint
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.ModalDrawer
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp



///////////////////////////////////////////////////

@Stable
interface AnimatedDrawerState {
    val drawerWidth: Float

    val drawerTranslationX: Float
    val drawerElevation: Float

    val contentScaleX: Float
    val contentScaleY: Float
    val contentTranslationX: Float
    val contentTransformOrigin: TransformOrigin

    suspend fun open()
    suspend fun close()
}

private const val AnimationDurationMillis = 600
private const val DrawerMaxElevation = 8f

// 1
@Stable
class AnimatedDrawerStateImpl(
    // 2
    override val drawerWidth: Float,
) : AnimatedDrawerState {

    // 3
    private val animation = Animatable(0f)

    // 4
    override val drawerTranslationX: Float
        get() = -drawerWidth * (1f - animation.value)

    // 5
    override val drawerElevation: Float
        get() = DrawerMaxElevation * animation.value

    // 6
    override val contentScaleX: Float
        get() = 1f - .2f * animation.value

    // 7
    override val contentScaleY: Float
        get() = 1f - .2f * animation.value

    // 8
    override val contentTranslationX: Float
        get() = drawerWidth * animation.value

    // 9
    override val contentTransformOrigin: TransformOrigin
        get() = TransformOrigin(pivotFractionX = 0f, pivotFractionY = .5f)

    // 10
    override suspend fun open() {
        animation.animateTo(
            targetValue = 1f,
            animationSpec = tween(
                durationMillis = AnimationDurationMillis,
            )
        )
    }

    // 11
    override suspend fun close() {
        animation.animateTo(
            targetValue = 0f,
            animationSpec = tween(
                durationMillis = AnimationDurationMillis,
            )
        )
    }
}

@Composable
fun rememberAnimatedDrawerState(
    drawerWidth: Dp,
): AnimatedDrawerState {
    val density = LocalDensity.current.density
    return remember {
        AnimatedDrawerStateImpl(
            drawerWidth = drawerWidth.value * density,
        )
    }
}

@Composable
fun AnimatedDrawer(
    // 1
    modifier: Modifier = Modifier,
    // 2
    state: AnimatedDrawerState = rememberAnimatedDrawerState(
        drawerWidth = 280.dp,
    ),
    // 3
    drawerContent: @Composable () -> Unit,
    // 4
    content: @Composable () -> Unit,
) {
    // 5
    Layout(
        // 6
        modifier = modifier,
        // 7
        content = {
            drawerContent()
            content()
        }
    ) { measurables, constraints ->
        // 8
        val (drawerContentMeasurable, contentMeasurable) = measurables
        // 9
        val drawerContentConstraints = Constraints.fixed(
            width = state.drawerWidth.coerceAtMost(constraints.maxWidth.toFloat()).toInt(),
            height = constraints.maxHeight,
        )
        // 10
        val drawerContentPlaceable = drawerContentMeasurable.measure(drawerContentConstraints)
        // 11
        val contentConstraints = Constraints.fixed(
            width = constraints.maxWidth,
            height = constraints.maxHeight,
        )
        // 12
        val contentPlaceable = contentMeasurable.measure(contentConstraints)
        // 13
        layout(
            width = constraints.maxWidth,
            height = constraints.maxHeight,
        ) {
            // 14
            contentPlaceable.placeRelativeWithLayer(
                IntOffset.Zero,
            ) {
                // 15
                transformOrigin = state.contentTransformOrigin
                scaleX = state.contentScaleX
                scaleY = state.contentScaleY
                translationX = state.contentTranslationX
            }
            // 16
            drawerContentPlaceable.placeRelativeWithLayer(
                IntOffset.Zero,
            ) {
                // 17
                translationX = state.drawerTranslationX
                shadowElevation = state.drawerElevation
            }
        }
    }
}
private const val CollapsedFaction = .2f
