package uz.madatbek.zoomradcompose.presenter.screens.viewcards

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Icon
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import org.orbitmvi.orbit.compose.collectAsState
import uz.madatbek.zoomradcompose.R
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.CardData
import uz.madatbek.zoomradcompose.ui.components.CardComponentForView
import uz.madatbek.zoomradcompose.utils.myLog


class ViewCardsScreen:Screen {
    @Composable
    override fun Content() {
        val viewModel=getViewModel<ViewCardsViewModel>()
        ViewCardsComponent(viewModel.collectAsState().value,viewModel::onEventDispatcher)
    }
}

@Composable
fun ViewCardsComponent(uiState: ViewCardsContract.UIState,onEventDispatchers:(ViewCardsContract.Intent)->Unit) {
    val data= remember {
        mutableStateOf(emptyList<CardData>())
    }
    when(uiState){
        is ViewCardsContract.UIState.LoadAllCards->{
            data.value=uiState.data
        }
    }
    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        Column {
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier
                    .width(56.dp)
                    .height(56.dp)
                    .align(Alignment.CenterStart)
                    .clickable(
                        onClick = {

                        },
                        indication = rememberRipple(
                            bounded = false,
                            radius = 36.dp
                        ),
                        interactionSource = remember { MutableInteractionSource() } // Источник взаимодействия
                    )
                ){
                    Icon(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .align(Alignment.Center),
                        painter = painterResource(id = R.drawable.ic_back_ios),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                }

                Text(
                    text = stringResource(id = R.string.view_cards_my_cards), modifier = Modifier.align(Alignment.Center),
                    color = Color.Gray
                )
            }

            LazyColumn(modifier = Modifier){
                items(data.value){
                    "cardData=> ${it.id}".myLog()
                    CardComponentForView(modifier = Modifier
                        .padding(top = 16.dp)
                        .fillMaxSize()
                        .padding(horizontal = 32.dp),
                        img =
                        when(it.themeType){
                            0->R.drawable.img_card1
                            1->R.drawable.img_card2
                            2->R.drawable.img_card3
                            3->R.drawable.img_card4
                            4->R.drawable.img_card5
                            5->R.drawable.img_card6
                            else->{
                                R.drawable.img_card7
                            }
                        }
                        ,
                        data=it
                    )
                }
            }
        }
    }
}



val data= arrayListOf(
    CardData(1,"",1222,"","0008 0008 0008 0008",324124,134,R.drawable.img_card4,true),
    CardData(1,"",1222,"","0008 0008 0008 0008",324124,134,R.drawable.img_card4,true),
    CardData(1,"",1222,"","0008 0008 0008 0008",324124,134,R.drawable.img_card4,true),
)
@Preview
@Composable
fun ViewCardsPreview() {
    ViewCardsComponent(ViewCardsContract.UIState.LoadAllCards(data)){

    }
}
