package uz.madatbek.zoomradcompose.data.model

data class UserData(
    val lastName:String,
    val firstName:String,
    val phone:String,
)