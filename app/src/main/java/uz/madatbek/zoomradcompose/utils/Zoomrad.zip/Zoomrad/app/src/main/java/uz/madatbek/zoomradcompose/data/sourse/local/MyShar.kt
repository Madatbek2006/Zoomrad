package uz.madatbek.zoomradcompose.data.sourse.local

import android.content.Context
import android.content.SharedPreferences
import uz.madatbek.zoomradcompose.data.model.LoginData
import uz.madatbek.zoomradcompose.utils.myLog

object MyShar {
    private lateinit var sharedPreferences:SharedPreferences
    fun init(context: Context){
        sharedPreferences=context.getSharedPreferences("Zoomrad",Context.MODE_PRIVATE)
    }

    fun setUserLoginData(loginData:LoginData){
        sharedPreferences.edit().putString("userPhone",loginData.phone).apply()
        sharedPreferences.edit().putString("userPassword",loginData.password).apply()
        sharedPreferences.edit().putString("userPINCode",loginData.pinCode).apply()
    }

    fun getUserLoginData():LoginData?{
        val phone= sharedPreferences.getString("userPhone","")?:""
        val password= sharedPreferences.getString("userPassword","")?:""
        val pinCode= sharedPreferences.getString("userPINCode","")?:""
        return LoginData(phone, pinCode,password)
    }

    fun setUserSMSToken(token:String){
        sharedPreferences.edit().putString("token",token).apply()
    }

    fun getSMSToken():String{
        return sharedPreferences.getString("token","")?:""
    }

    fun setRefreshToken(refreshToken:String){
        sharedPreferences.edit().putString("refreshToken",refreshToken).apply()
    }

    fun getRefreshToken():String{
        return sharedPreferences.getString("refreshToken","")?:""
    }

    fun setAccessToken(accessToken:String){

        "setAccessToken".myLog()
        sharedPreferences.edit().putString("accessToken",accessToken).apply()
    }

    fun getAccessToken():String{
        return sharedPreferences.getString("accessToken","")?:""
    }


    fun isAusUser():Boolean{
        return sharedPreferences.getBoolean("auzUser",false)
    }
    fun setAusUser(boolean: Boolean=true){
        sharedPreferences.edit().putBoolean("auzUser",boolean).apply()
    }


    fun isSingIn():Boolean{
        return sharedPreferences.getBoolean("singInUser",false)
    }
    fun setIsSingInUser(boolean: Boolean){
        sharedPreferences.edit().putBoolean("singInUser",boolean).apply()
    }
    fun setLanguage(language:String){
        sharedPreferences.edit().putString("language",language).apply()
    }
    fun getLanguage():String{
        return sharedPreferences.getString("language","ru")?:"ru"
    }
}

//AIzaSyCfNVrfaKfZrljIIQHLWhuDF6YT6PaQX9w