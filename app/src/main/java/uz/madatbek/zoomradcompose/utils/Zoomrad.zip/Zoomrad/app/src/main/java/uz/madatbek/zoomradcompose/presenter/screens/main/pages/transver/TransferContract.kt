package uz.madatbek.zoomradcompose.presenter.screens.main.pages.transver

import org.orbitmvi.orbit.ContainerHost
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.GetCardOwnerByPanData

interface TransferContract {

    interface Model:ContainerHost<UIState,SideEffect>{
        fun onEventDispatchers(intent: Intent)
    }
    interface UIState{
        data object InitUIState:UIState
        data class Text(val txt:String,val isSuccess:Boolean):UIState
    }

    interface SideEffect{
        data class Toast(val message:String):SideEffect
    }

    interface Intent{
        data object OpenAddScreen:Intent

        data class GetCardByPan(
            val pan:GetCardOwnerByPanData
        ):Intent
        data class Transfer(
            val pan:String,
            val amount:Long
        ):Intent
    }

}