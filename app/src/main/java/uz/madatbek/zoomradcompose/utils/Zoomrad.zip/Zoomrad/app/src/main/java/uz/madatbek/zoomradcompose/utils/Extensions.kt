package uz.madatbek.zoomradcompose.utils

import android.util.Log
import android.widget.Toast
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.ProducerScope
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.FlowCollector
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.orbitmvi.orbit.syntax.simple.SimpleSyntax
import org.orbitmvi.orbit.syntax.simple.reduce
import retrofit2.Response
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.CardData
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.StringData
import java.util.Locale
import kotlin.experimental.ExperimentalTypeInference


fun String.myLog() = Log.d("TTT", this)
fun String.onlyLetters() = all { it.isLetter() }
fun String.myShortToast(context: Context) {
    Toast.makeText(context, this, Toast.LENGTH_SHORT).show()
}

fun Context.checkPermission(array: List<String>, blockSuccess: () -> Unit) {
    "checkPermission".myLog()
    var isValid = true
    for (i in array.indices) {
        if (!isHavePermission(array[i]) && isValid) {
            isValid = false
            openSettings()
        }
    }
    if (isValid) {
        blockSuccess()
    }
}

fun Context.isHavePermission(permission: String): Boolean {
    return ContextCompat.checkSelfPermission(
        this,
        permission
    ) == PackageManager.PERMISSION_GRANTED
}

fun FragmentActivity.requestPermission(permission: Array<String>, rCode: Int = 0) {
    ActivityCompat.requestPermissions(
        this,
        permission,
        rCode
    )
}

fun Context.openSettings() {
    val intent = Intent(ACTION_APPLICATION_DETAILS_SETTINGS)
    " startActivity(intent)1".myLog()
    intent.data = Uri.parse("package:${this.packageName}")
    startActivity(intent)
}


//object Mapper {
//    fun QuerySnapshot.toUserDataList(): List<UserData> {
//        val userList = mutableListOf<UserData>()
//        for (document in documents) {
//            val id = document.id
//            val name = document.getString("name") ?: ""
//            val gmail = document.getString("gmail") ?: ""
//            val password = document.getString("password") ?: ""
//            val type = document.getString("type") ?: ""
//            val userData = UserData(id,name, gmail, password, type)
//            userList.add(userData)
//        }
//        return userList
//    }
//}
fun Context.setLocale(languageCode: String) {
    val locale = Locale(languageCode)
    Locale.setDefault(locale)
    val configuration = Configuration(this.resources.configuration)
    configuration.setLocale(locale)
    this.resources.updateConfiguration(configuration, this.resources.displayMetrics)
}


fun getCurrentLanguage(): String {
    return Locale.getDefault().language
}

fun <T> Response<T>.toResultData(): Result<T> {
    val gson = Gson()
    if (this.isSuccessful && this.body() != null) {
        return Result.success(this.body()!! as T)
    } else {
        val data:StringData?= gson.fromJson(this.errorBody()?.string()?:"Unknown error",StringData::class.java)
        return (Result.failure(Exception(data?.message?:"Unknown error")))
    }
}

context(FlowCollector<Result<T>>)
suspend fun <T>Result<T>.emitWith(){
    emit(this)
}

@OptIn(ExperimentalTypeInference::class)
public fun <T> safetyFlow(@BuilderInference block: suspend FlowCollector<T>.() -> Unit): Flow<T> = flow(block).flowOn(Dispatchers.IO).catch {}

suspend inline  fun <T:Any,E:Any> SimpleSyntax<T, E>.postUiState(value:T){
    reduce {value}
}


fun String.toValutaCard():String{
    return when(this.length){
        in 0..3->this
        4->{
            substring(0,1)+" "+substring(1,length)
        }
        5->{
            substring(0,2)+" "+substring(2,length)
        }
        6->{
            substring(0,3)+" "+substring(3,length)
        }
        7->{
            substring(0,1)+" "+substring(1,4)+" "+substring(4,length)
        }
        8->{
            substring(0,2)+" "+substring(2,5)+" "+substring(5,length)
        }
        9->{
            substring(0,3)+" "+substring(3,6)+" "+substring(6,length)
        }
        10->{
            substring(0,1)+" "+substring(1,4)+" "+substring(6,9)+" "+substring(9,length)
        }
        else-> "∞"

    }
}