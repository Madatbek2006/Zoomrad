package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class TransferItem1Data(
    @DrawableRes val icon:Int,
    val name:Int
)