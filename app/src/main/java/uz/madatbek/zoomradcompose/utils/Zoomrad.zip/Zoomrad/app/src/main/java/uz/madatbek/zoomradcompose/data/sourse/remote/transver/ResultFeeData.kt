package uz.madatbek.zoomradcompose.data.sourse.remote.transver

data class ResultFeeData(
    val fee:Int,
    val amount:Int
)