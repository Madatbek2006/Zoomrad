package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class HomeItem2Data(
    @DrawableRes val icon:Int,
    val  isNew:Boolean,
    val name:Int
)
