package uz.madatbek.zoomradcompose.presenter.screens.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cafe.adriel.voyager.core.model.ScreenModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.orbitmvi.orbit.syntax.simple.intent
import org.orbitmvi.orbit.viewmodel.container
import uz.madatbek.zoomradcompose.presenter.screens.createpin.CreatePinCodeScreen
import uz.madatbek.zoomradcompose.presenter.screens.login.LoginScreen
import uz.madatbek.zoomradcompose.presenter.screens.main.MainScreen
import uz.madatbek.zoomradcompose.presenter.screens.pincode.PinCodeScreen
import uz.madatbek.zoomradcompose.utils.navigation.AppNavigator
import javax.inject.Inject

@HiltViewModel
class SplashModel @Inject constructor(
    private val navigator: AppNavigator
) :SplashContract.Model,ViewModel(),ScreenModel {
    override val container= container<SplashContract.UIState,SplashContract.SideEffect>(SplashContract.UIState.InitState)


    override fun onEventDispatcher(intent: SplashContract.Intent) = intent{
        delay(100)
        when(intent){
            SplashContract.Intent.OpenLoginScreen->{

                    navigator.replace(LoginScreen())
            }
            SplashContract.Intent.OpenMainScreen->{
                    navigator.replace(PinCodeScreen())
            }
            SplashContract.Intent.OpenCreatePinCodeScreen->{
                navigator.replace(CreatePinCodeScreen())
            }

        }
    }

}