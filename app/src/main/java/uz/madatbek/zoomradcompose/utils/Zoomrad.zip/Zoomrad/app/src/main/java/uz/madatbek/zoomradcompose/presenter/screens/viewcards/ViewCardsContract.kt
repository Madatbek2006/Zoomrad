package uz.madatbek.zoomradcompose.presenter.screens.viewcards

import org.orbitmvi.orbit.ContainerHost
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.CardData

interface ViewCardsContract {

    interface Model:ContainerHost<UIState,SideEffect>{
        fun onEventDispatcher(intent: Intent)
    }

    interface UIState{
        data object InitUIState:UIState
        data class LoadAllCards(
            val data:List<CardData>
        ):UIState
    }

    interface SideEffect{
        data class Toast(val message:String):SideEffect
    }

    interface Intent{

    }

}
