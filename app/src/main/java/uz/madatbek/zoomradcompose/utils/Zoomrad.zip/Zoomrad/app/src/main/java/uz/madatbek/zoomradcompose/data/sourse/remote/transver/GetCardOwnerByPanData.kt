package uz.madatbek.zoomradcompose.data.sourse.remote.transver

data class GetCardOwnerByPanData(
    val pan:String
)