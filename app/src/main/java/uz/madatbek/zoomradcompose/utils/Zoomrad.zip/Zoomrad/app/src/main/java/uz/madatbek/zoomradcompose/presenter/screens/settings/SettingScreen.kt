package uz.madatbek.zoomradcompose.presenter.screens.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.Icon
import androidx.compose.material.Surface
import androidx.compose.material.Switch
import androidx.compose.material.Text
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import uz.madatbek.zoomradcompose.R
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.utils.Languages
import uz.madatbek.zoomradcompose.utils.getCurrentLanguage
import uz.madatbek.zoomradcompose.utils.myLog
import uz.madatbek.zoomradcompose.utils.setLocale

class SettingScreen:Screen {
    @Composable
    override fun Content() {
        val context= LocalContext.current
        val viewModel=getViewModel<SettingModel>()
        SettingComponent(viewModel::onEventDispatchers){
            context.setLocale(it)
            MyShar.setLanguage(it)
        }
    }
}

@Composable
fun SettingComponent(onEventDispatchers:(SettingContract.Intent)->Unit,onСhangeLanguage:(language:String)->Unit) {
    val changeLanguage= remember {
        mutableStateOf(getCurrentLanguage())
    }
    val isOpenLanguage= remember {
        mutableStateOf(false)
    }
    val isOpenNotification= remember {
        mutableStateOf(false)
    }
    val isOpenTheme= remember {
        mutableStateOf(false)
    }
    val monitorSwitch= remember {
        mutableStateOf(false)
    }
    val notificationSwitch1= remember {
        mutableStateOf(false)
    }
    val notificationSwitch2= remember {
        mutableStateOf(false)
    }

    Surface(
        modifier = Modifier.fillMaxSize()
    ) {
        if (changeLanguage.value!=""){
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(color = colorResource(id = R.color.app_bg))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)

                ) {
                    Icon(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(16.dp)
                            .size(24.dp)
                            .clickable(
                                onClick = {},
                                indication = rememberRipple(
                                    bounded = false,
                                    radius = 24.dp
                                ),
                                interactionSource = remember { MutableInteractionSource() }
                            ),
                        painter = painterResource(id = R.drawable.ic_back_ios),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                    Text(
                        text = stringResource(id = R.string.settings_settings_txt), modifier = Modifier.align(Alignment.Center),
                        color = Color.Gray
                    )
                }
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp)
                        .height(64.dp)
                        .clickable {
                            isOpenLanguage.value = !isOpenLanguage.value
                            getCurrentLanguage().myLog()
                        }
                    ) {
                        Icon(
                            modifier = Modifier
                                .padding(start = 32.dp)
                                .align(Alignment.CenterVertically)
                                .size(24.dp),
                            painter = painterResource(id = R.drawable.ic_network),
                            contentDescription = null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                        Text(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(start = 16.dp),
                            text = stringResource(id = R.string.settings_language_txt)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(end = 32.dp),
                            painter = if (isOpenLanguage.value) painterResource(id = R.drawable.arrow_up)else painterResource(
                                id = R.drawable.arrow_down), contentDescription =null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                    }
                    if (isOpenLanguage.value){
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp)
                                    .clickable {
                                        onСhangeLanguage(Languages.UZB)
                                        changeLanguage.value=Languages.UZB
                                        isOpenLanguage.value=false
                                    }
                                ,
                                text = "O'zbekcha"
                            )
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp)
                                    .clickable {
                                        onСhangeLanguage(Languages.RUS)
                                        changeLanguage.value=Languages.RUS
                                        isOpenLanguage.value=false
                                    }
                                ,
                                text = "Русский")
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp)
                                    .clickable {
                                        isOpenLanguage.value=false
                                    }
                                ,
                                text = "English")
                        }
                    }
                }
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp)
                    .height(64.dp)
                    .clickable {
                    }
                ) {
                    Icon(
                        modifier = Modifier
                            .padding(start = 32.dp)
                            .align(Alignment.CenterVertically)
                            .size(24.dp),
                        painter = painterResource(id = R.drawable.ic_lock),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                    Text(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(start = 16.dp),
                        text = stringResource(id = R.string.settings_sequrity_txt)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(end = 32.dp)
                            .size(16.dp),
                        painter = painterResource(id = R.drawable.arrow_next), contentDescription =null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                }
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp)
                    .height(64.dp)
                    .clickable {
                    }
                ) {
                    Icon(
                        modifier = Modifier
                            .padding(start = 32.dp)
                            .align(Alignment.CenterVertically)
                            .size(24.dp),
                        painter = painterResource(id = R.drawable.ic_monitoring_icon),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                    Text(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(start = 16.dp),
                        text = stringResource(id = R.string.settings_monitoring_txt)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Switch(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(end = 32.dp)
                            .size(24.dp),
                        checked = monitorSwitch.value,
                        onCheckedChange = {
                            monitorSwitch.value=!monitorSwitch.value
                        }
                    )
                }
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp)
                        .height(64.dp)
                        .clickable {
                            isOpenNotification.value = !isOpenNotification.value
                        }
                    ) {
                        Icon(
                            modifier = Modifier
                                .padding(start = 32.dp)
                                .align(Alignment.CenterVertically)
                                .size(24.dp),
                            painter = painterResource(id = R.drawable.ic_bell),
                            contentDescription = null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                        Text(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(start = 16.dp),
                            text = stringResource(id = R.string.settings_notification_txt)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(end = 32.dp),
                            painter = if (isOpenNotification.value) painterResource(id = R.drawable.arrow_up)else painterResource(
                                id = R.drawable.arrow_down), contentDescription =null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                    }
                    if (isOpenNotification.value){
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 16.dp),
                                text = stringResource(id = R.string.settings_notification_txt1))
                            Spacer(modifier = Modifier.weight(1f))
                            Switch(
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(end = 32.dp)
                                    .size(24.dp),
                                checked = notificationSwitch1.value,
                                onCheckedChange = {
                                    notificationSwitch1.value=!notificationSwitch1.value
                                }
                            )
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 16.dp),
                                text = stringResource(id = R.string.settings_notification_txt2))
                            Spacer(modifier = Modifier.weight(1f))
                            Switch(
                                modifier = Modifier
                                    .align(Alignment.CenterVertically)
                                    .padding(end = 32.dp)
                                    .size(24.dp),
                                checked = notificationSwitch2.value,
                                onCheckedChange = {
                                    notificationSwitch2.value=!notificationSwitch2.value
                                }
                            )
                        }

                    }
                }
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp)
                    .height(64.dp)
                    .clickable {
                    }
                ) {
                    Icon(
                        modifier = Modifier
                            .padding(start = 32.dp)
                            .align(Alignment.CenterVertically)
                            .size(24.dp),
                        painter = painterResource(id = R.drawable.ic_network),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                    Text(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(start = 16.dp),
                        text = stringResource(id = R.string.settings_public_ofera_txt)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        modifier = Modifier
                            .align(Alignment.CenterVertically)
                            .padding(end = 32.dp)
                            .size(16.dp),
                        painter = painterResource(id = R.drawable.arrow_next), contentDescription =null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                }
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp)
                        .height(64.dp)
                        .clickable {
                            isOpenTheme.value = !isOpenTheme.value
                        }
                    ) {
                        Icon(
                            modifier = Modifier
                                .padding(start = 32.dp)
                                .align(Alignment.CenterVertically)
                                .size(24.dp),
                            painter = painterResource(id = R.drawable.ic_network),
                            contentDescription = null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                        Text(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(start = 16.dp),
                            text = stringResource(id = R.string.settings_theme_txt)
                        )
                        Spacer(modifier = Modifier.weight(1f))
                        Icon(
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .padding(end = 32.dp),
                            painter = if (isOpenTheme.value) painterResource(id = R.drawable.arrow_up)else painterResource(
                                id = R.drawable.arrow_down), contentDescription =null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                    }
                    if (isOpenTheme.value){
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp),
                                text = stringResource(id = R.string.settings_theme_txt1))
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp),
                                text = stringResource(id = R.string.settings_theme_txt2))
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp),
                                text = stringResource(id = R.string.settings_theme_txt3))
                        }
                        Row {
                            Text(
                                modifier = Modifier
                                    .padding(start = 72.dp)
                                    .padding(vertical = 8.dp),
                                text = stringResource(id = R.string.settings_theme_txt4))
                        }
                    }
                }
            }
        }
    }
}

@Preview
@Composable
fun SettingPreview() {
    SettingComponent({}){}
}