package uz.madatbek.zoomradcompose.presenter.screens.sms

import org.orbitmvi.orbit.ContainerHost
import uz.madatbek.zoomradcompose.presenter.screens.pincode.PinCodeContract

interface SMSContract {

    interface Model:ContainerHost<UIState,SideEffect>{
            fun onEventDispatcher(intent: Intent)
    }

    sealed interface UIState{
        data object InitSate:UIState
    }

    sealed interface SideEffect{
        data class Toast(val massage:String):SideEffect
    }
    sealed interface Intent{
        data class OpenCreatePinCodeScreen(
            val sms:String
        ):Intent
    }


}

