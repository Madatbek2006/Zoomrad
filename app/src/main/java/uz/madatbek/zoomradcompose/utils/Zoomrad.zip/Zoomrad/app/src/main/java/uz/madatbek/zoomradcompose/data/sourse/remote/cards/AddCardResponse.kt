package uz.madatbek.zoomradcompose.data.sourse.remote.cards

data class AddCardResponse(
    val message:String
)