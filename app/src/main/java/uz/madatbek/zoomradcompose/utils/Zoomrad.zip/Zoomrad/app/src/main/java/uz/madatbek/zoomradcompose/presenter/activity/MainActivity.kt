package uz.madatbek.zoomradcompose.presenter.activity

import android.content.res.Configuration
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import cafe.adriel.voyager.navigator.CurrentScreen
import cafe.adriel.voyager.navigator.Navigator
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.presenter.screens.login.LoginScreen
import uz.madatbek.zoomradcompose.presenter.screens.main.MainScreen
import uz.madatbek.zoomradcompose.presenter.screens.splash.SplashScreen
import uz.madatbek.zoomradcompose.ui.theme.ZoomradTheme
import uz.madatbek.zoomradcompose.utils.myLog
import uz.madatbek.zoomradcompose.utils.navigation.NavigationHandler
import javax.inject.Inject
@AndroidEntryPoint
class MainActivity : FragmentActivity() {

    @Inject
    lateinit var navigationHandler: NavigationHandler
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        "onCreate".myLog()
        MyShar.init(this)
        setContent {
            ZoomradTheme {
                Navigator(screen = SplashScreen()) { navigator ->
                    navigationHandler.navigationStack
                        .onEach { it.invoke(navigator) }
                        .launchIn(lifecycleScope)
                    CurrentScreen()
                }
            }
        }
        this.supportFragmentManager
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Обработайте изменения конфигурации здесь
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Обработка изменения на альбомную ориентацию
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Обработка изменения на портретную ориентацию
        }
    }


}
