package uz.madatbek.zoomradcompose.data.sourse.remote.transver

data class TransferVerifyRequest(
    val token:String,
    val code:String
)