package uz.madatbek.zoomradcompose.domain

import kotlinx.coroutines.flow.Flow
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.TokensData
import uz.madatbek.zoomradcompose.presenter.screens.googlemap.MarkerData

interface DataRepository {
    fun getLocationsType(type:String):List<MarkerData>
}