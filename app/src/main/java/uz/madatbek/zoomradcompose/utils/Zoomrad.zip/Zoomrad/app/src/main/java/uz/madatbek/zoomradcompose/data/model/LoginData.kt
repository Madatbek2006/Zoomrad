package uz.madatbek.zoomradcompose.data.model

class LoginData(
    val phone:String?,
    val pinCode:String?,
    val password:String?,
)