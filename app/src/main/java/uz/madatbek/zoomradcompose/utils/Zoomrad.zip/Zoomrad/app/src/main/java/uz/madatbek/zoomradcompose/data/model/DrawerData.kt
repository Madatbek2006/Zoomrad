package uz.madatbek.zoomradcompose.data.model

import androidx.annotation.DrawableRes

data class DrawerData(
    val name:Int,
    @DrawableRes val icon:Int
)