package uz.madatbek.zoomradcompose.data.model

data class TestData(
    val i:Int
)
