package uz.madatbek.zoomradcompose.data.sourse.remote.singup

data class  StringData(
    val message:String
)