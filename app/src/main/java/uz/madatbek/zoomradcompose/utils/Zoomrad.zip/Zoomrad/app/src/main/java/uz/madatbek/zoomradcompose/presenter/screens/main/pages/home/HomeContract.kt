package uz.madatbek.zoomradcompose.presenter.screens.main.pages.home

import org.orbitmvi.orbit.ContainerHost

interface HomeContract {

    interface Model:ContainerHost<UIState,SideEffect>{
        fun onEventDispatchers(intent: Intent)
    }

    interface UIState{
        data object InitUIState:UIState
    }


    interface SideEffect{
        data class Toast(val message:String)
    }

    interface Intent{
        data object OpenAddScreen:Intent
        data object OpenViewCardsScreen:Intent
    }

}