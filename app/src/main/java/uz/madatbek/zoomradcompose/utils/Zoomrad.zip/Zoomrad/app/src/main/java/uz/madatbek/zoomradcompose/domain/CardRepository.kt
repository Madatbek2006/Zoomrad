package uz.madatbek.zoomradcompose.domain

import kotlinx.coroutines.flow.Flow
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.AddCardData
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.CardData
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.StringData
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.GetCardOwnerByPanData

interface CardRepository {
    fun addCard(card:AddCardData):Flow<Result<StringData>>

    fun getCardOwnerByPan(card:GetCardOwnerByPanData):Flow<Result<GetCardOwnerByPanData>>

    fun getAllCards():Flow<Result<List<CardData>>>

    fun deleteCard():Flow<Result<StringData>>

}