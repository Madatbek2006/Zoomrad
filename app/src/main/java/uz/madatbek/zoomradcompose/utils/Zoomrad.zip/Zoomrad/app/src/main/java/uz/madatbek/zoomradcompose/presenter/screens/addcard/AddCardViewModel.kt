package uz.madatbek.zoomradcompose.presenter.screens.addcard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cafe.adriel.voyager.core.model.ScreenModel
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import okhttp3.OkHttpClient
import org.orbitmvi.orbit.Container
import org.orbitmvi.orbit.syntax.simple.intent
import org.orbitmvi.orbit.syntax.simple.postSideEffect
import org.orbitmvi.orbit.viewmodel.container
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.data.sourse.remote.api.CardApi
import uz.madatbek.zoomradcompose.data.sourse.remote.api.Register
import uz.madatbek.zoomradcompose.data.sourse.remote.cards.AddCardData
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.TokensData
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.RefreshTokenData
import uz.madatbek.zoomradcompose.domain.CardRepository
import uz.madatbek.zoomradcompose.domain.DataRepository
import uz.madatbek.zoomradcompose.domain.impl.DataRepositoryImpl
import uz.madatbek.zoomradcompose.presenter.screens.googlemap.regionData
import uz.madatbek.zoomradcompose.utils.myLog
import uz.madatbek.zoomradcompose.utils.navigation.AppNavigator
import uz.madatbek.zoomradcompose.utils.safetyFlow
import javax.inject.Inject

@HiltViewModel
class AddCardViewModel @Inject constructor(
    private val navigator: AppNavigator,
    private val cardRepository: CardRepository
) : ViewModel(), ScreenModel, AddCardContract.Model {
    override val container =
        container<AddCardContract.UIState, AddCardContract.SideEffect>(AddCardContract.UIState.InitUIState)

    override fun onEventDispatchers(intent: AddCardContract.Intent) = intent {
        when (intent) {
            AddCardContract.Intent.OnBackScreen -> {
                navigator.back()
            }
            is AddCardContract.Intent.AddCard -> {
                cardRepository.addCard(intent.card).onEach { res ->
                    res.onSuccess {
                        postSideEffect(AddCardContract.SideEffect.Toast(message = it.message))
                        delay(200)
                        navigator.back()
                    }
                    res.onFailure {
                        postSideEffect(
                            AddCardContract.SideEffect.Toast(
                                message = it.message ?: "Unknown error!!"
                            )
                        )
                    }
                }.launchIn(viewModelScope)
            }
        }
    }

    private fun addCard(card: AddCardData): Flow<Result<String>> = safetyFlow {


    }
}

