package uz.madatbek.zoomradcompose.presenter.screens.googlemap

import androidx.lifecycle.ViewModel
import cafe.adriel.voyager.core.model.ScreenModel
import dagger.hilt.android.lifecycle.HiltViewModel
import org.orbitmvi.orbit.Container
import org.orbitmvi.orbit.syntax.simple.intent
import org.orbitmvi.orbit.syntax.simple.reduce
import org.orbitmvi.orbit.viewmodel.container
import uz.madatbek.zoomradcompose.domain.DataRepository
import uz.madatbek.zoomradcompose.utils.navigation.AppNavigator
import javax.inject.Inject

@HiltViewModel
class GoogleMapViewModel @Inject constructor(
    private val navigator: AppNavigator,
    private val repository: DataRepository
):ViewModel(),ScreenModel,GoogleMapContract.Model {


    val regionData=listOf("Филиалы","Центры К.О","Банкоматы","Обменные пункты")
    override val container=container<GoogleMapContract.UIState, GoogleMapContract.SideEffect>(GoogleMapContract.UIState.InitUIState(
        repository.getLocationsType(regionData[0])
    ),
    )



    override fun onEventDispatchers(intent: GoogleMapContract.Intent) =intent{
        when(intent){
            GoogleMapContract.Intent.OnClickBack->{
                navigator.back()
            }
            is GoogleMapContract.Intent.ClickType->{
                reduce {
                    GoogleMapContract.UIState.InitUIState(
                        data = repository.getLocationsType(intent.name)
                    )
                }
            }
        }
    }


}