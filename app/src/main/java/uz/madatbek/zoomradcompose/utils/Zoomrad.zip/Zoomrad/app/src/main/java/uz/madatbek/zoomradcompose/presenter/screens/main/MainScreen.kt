package uz.madatbek.zoomradcompose.presenter.screens.main

import android.annotation.SuppressLint
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.BottomNavigation
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Scaffold
import androidx.compose.material.Surface
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import cafe.adriel.voyager.navigator.tab.CurrentTab
import cafe.adriel.voyager.navigator.tab.TabNavigator
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.launch
import uz.madatbek.zoomradcompose.R
import uz.madatbek.zoomradcompose.data.model.DrawerData
import uz.madatbek.zoomradcompose.presenter.screens.draver.DrawerValue
import uz.madatbek.zoomradcompose.presenter.screens.draver.MyModalDrawer
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.help.HelpPage
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.home.HomePage
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.more.MorePage
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.payments.OutlinedTextExample
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.payments.PaymentsPage
import uz.madatbek.zoomradcompose.presenter.screens.main.pages.transver.TransferPage
import uz.madatbek.zoomradcompose.ui.theme.ZoomradTheme
import uz.madatbek.zoomradcompose.utils.TabNavigatorItem
import uz.madatbek.zoomradcompose.presenter.screens.main.draver.MyDrawer

class MainScreen : Screen {

    @Composable
    override fun Content() {
        val viewModel=getViewModel<MainViewModel>()
        ZoomradTheme {
//            MainComponent()

            HomeComponent(viewModel::onEventDispatcher)
        }
    }
}


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun MainComponent(
    modifier: Modifier,
    onOpenClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(color = colorResource(id = R.color.app_bg))
    ) {
        TabNavigator(tab = HomePage) {
            Scaffold(
                topBar = {

                    when (it.current) {

                        HomePage -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(color = colorResource(id = R.color.app_bg))
                            ) {
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(16.dp)
                                        .clickable(
                                            onClick = onOpenClick,
                                            indication = rememberRipple(
                                                bounded = false,
                                                radius = 24.dp
                                            ),
                                            interactionSource = remember { MutableInteractionSource() }
                                        ),
                                    painter = painterResource(id = R.drawable.ic_menu),
                                    contentDescription = null
                                )
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(16.dp),
                                    painter = painterResource(id = R.drawable.ic_bell),
                                    contentDescription = null,
                                    colorFilter = ColorFilter.tint(Color.Blue)
                                )
                            }
                        }

                        MorePage -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(color = colorResource(id = R.color.app_bg))
                            ) {
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(16.dp)
                                        .clickable(
                                            onClick = onOpenClick,
                                            indication = rememberRipple(
                                                bounded = false,
                                                radius = 24.dp
                                            ),
                                            interactionSource = remember { MutableInteractionSource() }
                                        ),
                                    painter = painterResource(id = R.drawable.ic_menu),
                                    contentDescription = null
                                )
                                androidx.compose.material.Text(
                                    text = stringResource(id = R.string.main_screen_more), modifier = Modifier.align(Alignment.Center),
                                    color = Color.Gray
                                )
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(20.dp),
                                    painter = painterResource(id = R.drawable.ic_menu_for_more),
                                    contentDescription = null,
                                    colorFilter = ColorFilter.tint(color = colorResource(id = R.color.zumrat))
                                )
                            }
                        }

                        TransferPage -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(color = colorResource(id = R.color.app_bg))
                            ) {
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(16.dp)
                                        .clickable(
                                            onClick = onOpenClick,
                                            indication = rememberRipple(
                                                bounded = false,
                                                radius = 24.dp
                                            ),
                                            interactionSource = remember { MutableInteractionSource() }
                                        ),
                                    painter = painterResource(id = R.drawable.ic_menu),
                                    contentDescription = null
                                )
                                androidx.compose.material.Text(
                                    text = stringResource(id = R.string.main_screen_transver_card_in_card),
                                    modifier = Modifier.align(Alignment.Center),
                                    color = Color.Gray
                                )
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(16.dp),
                                    painter = painterResource(id = R.drawable.ic_bell),
                                    contentDescription = null,
                                    colorFilter = ColorFilter.tint(Color.Blue)
                                )
                            }
                        }

                        PaymentsPage -> {
                            val textState = remember { mutableStateOf("") }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(color = colorResource(id = R.color.app_bg))
                            ) {
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(16.dp)
                                        .clickable(
                                            onClick = onOpenClick,
                                            indication = rememberRipple(
                                                bounded = false,
                                                radius = 24.dp
                                            ),
                                            interactionSource = remember { MutableInteractionSource() }
                                        ),
                                    painter = painterResource(id = R.drawable.ic_menu),
                                    contentDescription = null
                                )

                                OutlinedTextExample(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .clip(RoundedCornerShape(300.dp))
                                        .background(Color.White), textState = textState
                                )
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterEnd)
                                        .padding(16.dp),
                                    painter = painterResource(id = R.drawable.ic_bell),
                                    contentDescription = null,
                                    colorFilter = ColorFilter.tint(Color.Blue)
                                )
                            }
                        }

                        HelpPage -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .background(color = colorResource(id = R.color.app_bg))
                            ) {
                                Image(
                                    modifier = Modifier
                                        .align(Alignment.CenterStart)
                                        .padding(16.dp)
                                        .clickable(
                                            onClick = onOpenClick,
                                            indication = rememberRipple(
                                                bounded = false,
                                                radius = 24.dp
                                            ),
                                            interactionSource = remember { MutableInteractionSource() }
                                        ),
                                    painter = painterResource(id = R.drawable.ic_menu),
                                    contentDescription = null
                                )
                                androidx.compose.material.Text(
                                    text = stringResource(id = R.string.main_screen_help_support),
                                    modifier = Modifier.align(Alignment.Center),
                                    color = Color.Gray
                                )
                            }
                        }
                    }

                },
                content = {

                    CurrentTab()
                },
                bottomBar = {
                    BottomNavigation(
                        backgroundColor = Color.White,
                    ) {
                        TabNavigatorItem(tab = HomePage)
                        TabNavigatorItem(tab = PaymentsPage)
                        TabNavigatorItem(tab = TransferPage)
                        TabNavigatorItem(tab = HelpPage)
                        TabNavigatorItem(tab = MorePage)
                    }
                },
            )
        }
    }
}

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun HomeComponent(onEventDispatchers:(MainContract.Intent)->Unit) {
    val drawerState =
        uz.madatbek.zoomradcompose.presenter.screens.draver.rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val configuration = LocalConfiguration.current
    val intWith=configuration.screenWidthDp
    val screenWidth = intWith.dp
    val drawerWidth = screenWidth * 0.5f
    val drawerWidthPx = with(density) { drawerWidth.toPx() }

    var lastOffset = 0f
    val drawerOffsetFlow = remember {
        snapshotFlow {
            drawerState.offset
        }.filter { _ ->
            return@filter true
        }
    }
    var oldProgress=0.1f
    var progress:Float=0f
    progress= if ((oldProgress*10).toInt()!=(progress*10).toInt()){
        oldProgress=progress
        drawerOffsetFlow.collectAsState(initial = 0f).value / drawerWidthPx
    } else{
        progress
    }
    val targetValue=1+((0.9-1)*(progress+2))/(0+2)
    val scale = animateFloatAsState(targetValue = targetValue.toFloat(), label = "")
    val xOffset = animateFloatAsState(targetValue = (((intWith*0.9f)*(progress+2))/2).toFloat(), label = "")
    MyModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            MyDrawer(modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.85f),
                onClickProfile = {
                    scope.launch {
                        drawerState.close()
                    }
                    onEventDispatchers(MainContract.Intent.OpenProfileScreen)
                },
                onClickDrawerData = {
                    onEventDispatchers(MainContract.Intent.OnCLickDrawerData(it))
                }
            )
        },
        content = {
            Box(
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                        translationX = xOffset.value
                    }
                    .fillMaxSize()
            ) {
                MainComponent(modifier = Modifier.fillMaxSize()) {
                    scope.launch {
                        if (drawerState.isClosed) drawerState.open() else drawerState.close()
                    }
                }
            }
        }
    )


}


@Preview
@Composable
fun PreviewAnimation() {
   HomeComponent({

   })
}







val drawerData = arrayListOf(
    DrawerData(name = R.string.drawer_profile_txt, icon = R.drawable.ic_user),
    DrawerData(R.string.drawer_settings_txt, R.drawable.ic_settings),
    DrawerData(R.string.drawer_history_txt, R.drawable.ic_history_new),
    DrawerData(R.string.drawer_monitoring_txt, R.drawable.ic_monitoring_icon),
    DrawerData(R.string.drawer_help_txt, R.drawable.ic_chat),
    DrawerData(R.string.drawer_share_txt, R.drawable.ic_share),
    DrawerData(R.string.drawer_exit_txt, R.drawable.ic_exit),
)


