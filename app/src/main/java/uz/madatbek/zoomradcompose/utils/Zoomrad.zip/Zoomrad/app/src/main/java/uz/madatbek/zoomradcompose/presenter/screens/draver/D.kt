//import androidx.compose.animation.core.animateFloatAsState
//import androidx.compose.foundation.background
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.material.*
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.graphics.graphicsLayer
//import androidx.compose.ui.tooling.preview.Preview
//import kotlinx.coroutines.launch
//
//@Composable
//fun AnimatedZoomDrawer() {
//    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
//    val scope = rememberCoroutineScope()
//    val scale = animateFloatAsState(targetValue = if (drawerState.isClosed) 1f else 0.85f,
//        label = ""
//    )
//    val xOffset = animateFloatAsState(targetValue = if (drawerState.isClosed) 0f else 150f,
//        label = ""
//    )
//
//    ModalDrawer(
//        drawerState = drawerState,
//        drawerContent = {
//            DrawerContent { scope.launch { drawerState.close() } }
//        },
//        content = {
//            Box(
//                modifier = Modifier
//                    .graphicsLayer {
//                        scaleX = scale.value
//                        scaleY = scale.value
//                        translationX = xOffset.value * density
//                    }
//                    .fillMaxSize()
//            ) {
//                MainContent {
//                    scope.launch {
//                        if (drawerState.isClosed) drawerState.open() else drawerState.close()
//                    }
//                }
//            }
//        }
//    )
//}
//
//@Composable
//fun DrawerContent(onClose: () -> Unit) {
//    // Ваше содержимое Drawer
//    Button(onClick = onClose) {
//        Text("Закрыть")
//    }
//}
//
//@Composable
//fun MainContent(toggleDrawer: () -> Unit) {
//    Box(modifier = Modifier.fillMaxSize().background(Color.Red)){
//        Button(
//            modifier = Modifier.align(Alignment.Center),
//            onClick = toggleDrawer
//        ) {
//            Text("Переключить Drawer")
//        }
//    }
//}
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import uz.madatbek.zoomradcompose.presenter.screens.draver.DrawerValue
import uz.madatbek.zoomradcompose.presenter.screens.draver.MyModalDrawer
import uz.madatbek.zoomradcompose.utils.myLog

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun AnimatedZoomDrawer() {
    val drawerState =
        uz.madatbek.zoomradcompose.presenter.screens.draver.rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    // Задаем фиксированную ширину Drawer
    val drawerWidthPx = with(density) { 256.dp.toPx() }

    // Отслеживаем смещение Drawer
    val drawerOffsetFlow = remember {
        snapshotFlow { drawerState.offset }
    }

    val progress = drawerOffsetFlow.collectAsState(initial = 0f).value / drawerWidthPx
    val scale = animateFloatAsState(targetValue =  0.9f-0.0667f*progress, label = "")
    val xOffset = animateFloatAsState(targetValue = 200f * progress, label = "")
    "xOffset=> ${xOffset.value}\nscale=>${scale.value}\nprogress=>$progress".myLog()
    val configuration = LocalConfiguration.current
    val screenWidth = configuration.screenWidthDp.dp
    val drawerWidth = screenWidth * 0.5f // 80% от ширины экрана
    MyModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            Box(
                modifier = Modifier.fillMaxHeight().fillMaxWidth(0.85f).background(Color.Blue)
            ) {
                DrawerContent(onClose = { scope.launch { drawerState.close() } })
            }
        },
        content = {
            Box(
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                        translationX = xOffset.value + 300
                    }
                    .fillMaxSize()
                    .background(Color.Red)
            ) {
                MainContent {
                    scope.launch {
                        if (drawerState.isClosed) drawerState.open() else drawerState.close()
                    }
                }
            }
        }
    )
}

@Composable
fun DrawerContent(onClose: () -> Unit) {

    Box(modifier = Modifier){
        Button(onClick = onClose) {
            Text("Закрыть")
        }
    }
}

@Composable
fun MainContent(toggleDrawer: () -> Unit) {
    Box(modifier = Modifier
        .fillMaxSize()
        .background(Color.Red)) {
        Button(
            modifier = Modifier.align(Alignment.Center),
            onClick = toggleDrawer
        ) {
            Text("Переключить Drawer")
        }
    }
}

@Preview
@Composable
fun PreviewAnimatedZoomDrawer() {
    AnimatedZoomDrawer()
}
