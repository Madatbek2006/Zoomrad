package uz.madatbek.zoomradcompose.presenter.screens.googlemap

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.location.Geocoder
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.AlertDialog
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Icon
import androidx.compose.material.ModalBottomSheetLayout
import androidx.compose.material.ModalBottomSheetValue
import androidx.compose.material.Text
import androidx.compose.material.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.currentComposer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import cafe.adriel.voyager.core.screen.Screen
import cafe.adriel.voyager.hilt.getViewModel
import com.google.android.gms.dynamic.ObjectWrapper
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import kotlinx.coroutines.launch
import org.orbitmvi.orbit.compose.collectAsState
import uz.madatbek.zoomradcompose.R
import uz.madatbek.zoomradcompose.utils.myLog
import java.io.IOException
import java.util.Date
import java.util.Locale

class GoogleMapScreen : Screen {
    @Composable
    override fun Content() {
        val viewModel = getViewModel<GoogleMapViewModel>()
        MyGoogleMap(
            modifier = Modifier.fillMaxSize(),
            viewModel::onEventDispatchers,
            uiState = viewModel.collectAsState().value,
        )
    }

}
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun MyGoogleMap(
    modifier: Modifier,
    onEventDispatchers: (GoogleMapContract.Intent) -> Unit,
    uiState: GoogleMapContract.UIState
) {
    val isCard= remember { mutableStateOf(false) }
    val context = LocalContext.current
    val posLs = remember { mutableStateOf((uiState as GoogleMapContract.UIState.InitUIState).data) }
    val myMarkerBitmap by lazy { bitmapDescriptorFromVector(context,R.drawable.ic_map_marker)}
    val regionType = remember { mutableStateOf(regionData[0]) }
    val sheetState = rememberModalBottomSheetState(initialValue = ModalBottomSheetValue.Hidden)
    val coroutineScope = rememberCoroutineScope()
    val currentMarkerData= remember { mutableStateOf(MarkerData(posLs.value[0].lat,posLs.value[0].lng,"","","")) }
    val cameraPos = rememberCameraPositionState { position = CameraPosition.fromLatLngZoom(LatLng(currentMarkerData.value.lat, currentMarkerData.value.lng), 17f) }
    val isClickPos= remember { mutableStateOf(false) }
    ModalBottomSheetLayout(
        sheetState = sheetState,
        sheetContent = {
           GoogleMapItem2(data = currentMarkerData.value){
               coroutineScope.launch { sheetState.hide() }
               context.openMap(it)
           }
        },
        sheetShape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
    ) {
        Column(modifier = modifier) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(color = colorResource(id = R.color.app_bg))
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(modifier = Modifier
                        .width(56.dp)
                        .height(56.dp)
                        .align(Alignment.CenterStart)
                        .clickable {
                            onEventDispatchers(GoogleMapContract.Intent.OnClickBack)
                        }
                    ) {
                        Icon(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp)
                                .align(Alignment.Center),
                            painter = painterResource(id = R.drawable.ic_back_ios),
                            contentDescription = null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                    }

                    Text(
                        text = regionType.value, modifier = Modifier.align(Alignment.Center),
                        color = Color.Gray
                    )

                    Box(modifier = Modifier
                        .width(56.dp)
                        .height(56.dp)
                        .align(Alignment.CenterEnd)
                        .clickable {
                            isCard.value = !isCard.value
                        }
                    ) {
                        Icon(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp)
                                .align(Alignment.Center),
                            painter = painterResource(id =if(!isCard.value)R.drawable.ic_map else R.drawable.ic_menu_for_more),
                            contentDescription = null,
                            tint = colorResource(id = R.color.zumrat)
                        )
                    }
                }

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)){
                    Text(modifier = Modifier
                        .padding(start = 16.dp)
                        .padding(top = 8.dp)
                        .padding(bottom = 8.dp)
                        .align(Alignment.CenterStart),

                        text = "Все",
                        fontSize = 12.sp
                    )
                    Icon(
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .width(16.dp)
                            .height(16.dp)
                            .align(Alignment.CenterEnd),
                        painter = painterResource(id = R.drawable.arrow_down),
                        contentDescription = null,
                        tint = colorResource(id = R.color.zumrat)
                    )
                }
                LazyRow(modifier=Modifier.padding(bottom = 16.dp)){
                    items(regionData){
                        GoogleMapItem(isCheck =regionType.value==it, data = it){data->
                            regionType.value=data
                            onEventDispatchers(GoogleMapContract.Intent.ClickType(data))
                        }
                    }
                }
            }
            if (isCard.value){
                GoogleMap(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    cameraPositionState = cameraPos,
                    uiSettings = MapUiSettings(myLocationButtonEnabled = true, zoomControlsEnabled = false),
                    properties = MapProperties(isMyLocationEnabled = true, isBuildingEnabled = true, isTrafficEnabled = true),
                ) {
                    posLs.value.forEach {markerData->
                        Marker(
                            state = MarkerState(position = LatLng(markerData.lat, markerData.lng)),
                            onClick = {
                                currentMarkerData.value=markerData
                                coroutineScope.launch { sheetState.show() }
                                isClickPos.value=true
                                return@Marker true
                            },
                            icon = myMarkerBitmap,
                        )
                    }
                }
                "isClickPos.value=> ${isClickPos.value}".myLog()
                if (isClickPos.value){

                    LaunchedEffect(key1 = currentMarkerData.value) {
                        cameraPos.animate(CameraUpdateFactory.newLatLngZoom(LatLng(currentMarkerData.value.lat,currentMarkerData.value.lng), 17f))
                        isClickPos.value=false
                        coroutineScope.launch { sheetState.show() }
                    }
                }
            } else{
                LazyColumn(
                    modifier= Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(colorResource(id = R.color.app_bg))
                ){
                    items(posLs.value){
                        GoogleMapItem3(data = it){
                            isCard.value=true
                            currentMarkerData.value=it
                            isClickPos.value=true
                        }
                    }
                }
            }

        }
    }
    when (uiState) {
        is GoogleMapContract.UIState.InitUIState -> {
            posLs.value = uiState.data

        }

        is GoogleMapContract.UIState.RegionType -> {

        }
    }
}

data class MarkerData(
    val lat: Double,
    val lng: Double,
    val name: String,
    val adress:String,
    val time:String
)



@Composable
fun GoogleMapItem(isCheck:Boolean,data: String,onClickItem:(data:String)->Unit) {
    Box(modifier = Modifier
        .padding(start = 16.dp, top = 16.dp)
        .clip(RoundedCornerShape(16.dp))
        .background(
            color = if (isCheck) colorResource(
                id = R.color.zumrat
            ) else Color.White
        )
        .clickable {
            onClickItem(data)
        }
        .padding(16.dp)

    ) {
        Text(text = data,
            color = if (isCheck) Color.White else Color.Black)
    }
}


@Preview
@Composable
fun GoogleMapPreview() {
    MyGoogleMap(
        modifier = Modifier.fillMaxSize(),
        {},
        GoogleMapContract.UIState.InitUIState(emptyList())
    )
}


val regionData=listOf("Филиалы","Центры К.О","Банкоматы","Обменные пункты")
fun bitmapDescriptorFromVector(context: Context, vectorResId: Int): BitmapDescriptor? {
    return ContextCompat.getDrawable(context, vectorResId)?.run {
        setBounds(0, 0, intrinsicWidth, intrinsicHeight)
        val bitmap = Bitmap.createBitmap(intrinsicWidth, intrinsicHeight, Bitmap.Config.ARGB_8888)
        draw(android.graphics.Canvas(bitmap))
        BitmapDescriptorFactory.fromBitmap(bitmap)
    }
}
@Composable
fun GoogleMapItem2(data:MarkerData,onClickItem: (data: MarkerData) -> Unit){
    Column(modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(topEnd = 16.dp, topStart = 16.dp))
        .background(colorResource(id = R.color.app_bg)))
    {
        Box(modifier = Modifier
            .padding(top = 16.dp)
            .width(32.dp)
            .height(8.dp)
            .clip(RoundedCornerShape(300.dp))
            .background(Color.Gray)
            .align(Alignment.CenterHorizontally))

        Text(
            modifier = Modifier.padding(start = 16.dp, top = 16.dp),
            text = data.name,
            fontSize = 16.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 16.dp)
                .height(48.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
            ){
                Icon(
                    modifier = Modifier.align(Alignment.Center),
                    painter = painterResource(id = R.drawable.ic_map_marker_info),
                    contentDescription = null,
                    tint = colorResource(id = R.color.zumrat)
                )
            }
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                text = data.adress,
            )

        }
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 8.dp)
                .height(48.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
            ){
                Icon(
                    modifier = Modifier.align(Alignment.Center),
                    painter = painterResource(id = R.drawable.ic_map_marker_info),
                    contentDescription = null,
                    tint = colorResource(id = R.color.zumrat)
                )
            }
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                text = data.time
                ,
            )
        }
        Card(modifier = Modifier
            .padding(horizontal = 32.dp, vertical = 32.dp)
            .padding(bottom = 16.dp)
            .fillMaxWidth()
            .height(48.dp)
            .clip(
                RoundedCornerShape(8.dp)
            )
            .clickable {
                onClickItem(data)
            }
        ) {
            Box(modifier = Modifier.fillMaxSize()){
                Text(
                    modifier = Modifier.align(Alignment.Center),
                    text = "Маршрут",)
            }
        }
    }
}
@Composable
fun GoogleMapItem3(data:MarkerData,onClickItem: (data: MarkerData) -> Unit){
    Column(modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(topEnd = 16.dp, topStart = 16.dp))
        .background(colorResource(id = R.color.app_bg))
        .clickable {
            onClickItem(data)
        }
    )
    {

        Text(
            modifier = Modifier.padding(start = 16.dp, top = 16.dp),
            text = data.name,
            fontSize = 16.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 16.dp)
                .height(48.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
            ){
                Icon(
                    modifier = Modifier.align(Alignment.Center),
                    painter = painterResource(id = R.drawable.ic_map_marker_info),
                    contentDescription = null,
                    tint = colorResource(id = R.color.zumrat)
                )
            }
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                text = data.adress,
            )

        }
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 8.dp, bottom = 16.dp)
                .height(48.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
            ){
                Icon(
                    modifier = Modifier.align(Alignment.Center),
                    painter = painterResource(id = R.drawable.ic_map_marker_info),
                    contentDescription = null,
                    tint = colorResource(id = R.color.zumrat)
                )
            }
            Text(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                text = data.time
                ,
            )
        }

    }
}

fun Context.openMap(data:MarkerData){
    val uri = Uri.parse("geo:${data.lat},${data.lng}?z=${12}")
    val mapIntent = Intent(Intent.ACTION_VIEW, uri)
    mapIntent.resolveActivity(packageManager)?.let {
        startActivity(Intent.createChooser(mapIntent, "Открыть с помощью"))
    }
}

//fun fetchPlaceDetails(context: Context, data: LatLng, completion: (List<String>) -> Unit) {
//    val geocoder = Geocoder(context, Locale.getDefault())
//
//    try {
//        val addresses = geocoder.getFromLocation(data.latitude, data.longitude, 1)
//        if (!addresses.isNullOrEmpty()) {
//            val ls = ArrayList<String>()
//            val address = addresses[0] // Берем первый и, как правило, самый релевантный адрес
//            val fullAddress = address.getAddressLine(0)
//            val country = address.countryName
//            val state = address.adminArea
//            val city = address.locality
//            val postalCode = address.postalCode
//            val street = address.thoroughfare
//            val name = address.featureName
//
//            val details =
//                "Full address: $fullAddress\nCountry: $country\nState/Province: $state\nCity: $city\nPostal Code: $postalCode\nStreet: $street\nFeatureName: $name"
//            completion(arrayListOf(details))
//        } else {
//            completion(arrayListOf("No address found"))
//        }
//    } catch (e: IOException) {
//        e.printStackTrace()
//        completion(arrayListOf("Error: ${e.message}"))
//    }
//}