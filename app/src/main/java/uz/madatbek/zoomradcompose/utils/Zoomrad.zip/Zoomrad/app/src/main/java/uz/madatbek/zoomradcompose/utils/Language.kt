package uz.madatbek.zoomradcompose.utils

object Languages {
    val RUS="ru"
    val UZB="uz"
}