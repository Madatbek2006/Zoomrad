package uz.madatbek.zoomradcompose.domain.impl

import android.view.PixelCopy.Request
import kotlinx.coroutines.flow.Flow
import uz.madatbek.zoomradcompose.data.sourse.local.MyShar
import uz.madatbek.zoomradcompose.data.sourse.remote.api.TransferApi
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.SMSTokenData
import uz.madatbek.zoomradcompose.data.sourse.remote.singup.StringData
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.TransferRequest
import uz.madatbek.zoomradcompose.data.sourse.remote.transver.TransferVerifyRequest
import uz.madatbek.zoomradcompose.domain.TransferRepository
import uz.madatbek.zoomradcompose.utils.emitWith
import uz.madatbek.zoomradcompose.utils.safetyFlow
import uz.madatbek.zoomradcompose.utils.toResultData
import javax.inject.Inject

class TransferRepositoryImpl @Inject constructor(
    private val transferApi: TransferApi
):TransferRepository {
    override fun transferFOrCard(transferRequest: TransferRequest): Flow<Result<SMSTokenData>> = safetyFlow{
        transferApi.transferForCart(transferRequest = transferRequest, authorization = MyShar.getAccessToken())
            .toResultData()
            .emitWith()
    }

    override fun transferVerify(transferVerify: TransferVerifyRequest): Flow<Result<StringData>> = safetyFlow{
        transferApi.transferVerify(transferVerify,MyShar.getAccessToken())
            .toResultData()
            .emitWith()
    }


}